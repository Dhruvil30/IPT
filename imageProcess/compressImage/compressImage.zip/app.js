const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const Jimp = require('jimp');

const INPUT_BUCKET_NAME = process.env.INPUT_BUCKET_NAME;
const OUTPUT_BUCKET_NAME = process.env.OUTPUT_BUCKET_NAME;
const URL_EXPIRATION = 3600;

exports.lambdaHandler = async (event) => {
    try {
        const { key, email } = event;

        const s3Data = await s3.getObject({
            Bucket: INPUT_BUCKET_NAME,
            Key: key
        }).promise();

        const imageBuffer = s3Data.Body;
        const image = await Jimp.read(imageBuffer);

        const compressedBuffer = await image.quality(70).getBufferAsync(Jimp.AUTO);

        const outputKey = `${key.replace(/\..+$/, '')}-compressed.jpg`;

        await s3.putObject({
            Bucket: OUTPUT_BUCKET_NAME,
            Key: outputKey,
            Body: compressedBuffer
        }).promise();

        const presignedUrl = s3.getSignedUrl('getObject', {
            Bucket: OUTPUT_BUCKET_NAME,
            Key: outputKey,
            Expires: URL_EXPIRATION
        });

        return {
            statusCode: 200,
            body: JSON.stringify({
                message: 'Image compression successful.',
                url: presignedUrl,
                email
            })
        };
    } catch (error) {
        console.log('Error in compressImage function:', error);
        return {
            statusCode: 500,
            error,
        };
    }
};
